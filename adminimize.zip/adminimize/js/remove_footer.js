/**
 * Remove footer area.
 */
jQuery( document ).ready( function( $ ) {
	$( '#wpfooter, #footer-upgrade' ).remove();
} );
