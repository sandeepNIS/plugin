<?php


namespace Nextend\Framework\Form\Container;


use Nextend\Framework\Form\ContainerGeneral;

class ContainerAlternative extends ContainerGeneral {

    public function renderContainer() {

    }
}