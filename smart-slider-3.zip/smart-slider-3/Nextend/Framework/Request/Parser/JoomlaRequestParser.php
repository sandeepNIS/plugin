<?php

namespace Nextend\Framework\Request\Parser;

class JoomlaRequestParser extends AbstractRequestParser {

    public function parseData($data) {
        return $data;
    }
}