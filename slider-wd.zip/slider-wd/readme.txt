=== Sliderby10Web===
Contributors: webdorado,10web
Tags: responsive slider, slider, slideshow, wordpress slider, image slider, gallery slider, images slider, Photo Slider, post slider,  slider plugin
Requires at least: 3.4
Tested up to: 5.0
Requires PHP: 5.2
Stable tag: 1.2.54
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

10Web