<?php

class BoosterModel {}
